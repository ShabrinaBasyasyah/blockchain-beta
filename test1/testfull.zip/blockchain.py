import hashlib
import json
from datetime import datetime
from permintaan import Permintaan
from penawaran import Penawaran
from transaksi import Transaksi

class Block:
    def __init__(self, timestamp, data, previous_hash):
        self.timestamp = timestamp
        self.data = data
        self.previous_hash = previous_hash
        self.hash = self.calculate_hash()

    def calculate_hash(self):
        data_encoded = json.dumps(self.data, sort_keys=True).encode()
        return hashlib.sha256(str(self.timestamp).encode() + data_encoded + str(self.previous_hash).encode()).hexdigest()

class Blockchain:
    def __init__(self):
        self.blocks = []
        self.genesis_block = Block(0, {"permintaan": {}}, "0")
        self.blocks.append(self.genesis_block)

    def add_block(self, data):
        if isinstance(data, Permintaan):
            data_dict = data.to_dict()
            new_block = Block(datetime.now().timestamp(), data_dict, self.blocks[-1].hash)
            new_block.hash = new_block.calculate_hash()
            self.blocks.append(new_block)
        elif isinstance(data, Penawaran):
            data_dict = data.to_dict()
            new_block = Block(datetime.now().timestamp(), {"penawaran": data_dict}, self.blocks[-1].hash)
            new_block.hash = new_block.calculate_hash()
            self.blocks.append(new_block)
        else:
            raise ValueError("Data yang diberikan harus berupa objek permintaan atau penawaran")

    def get_latest_block(self):
        return self.blocks[-1]

    def calculate_total_emissions(self):
        total_emissions = 0
        for block in self.blocks:
            if "permintaan" in block.data and "ptbae_diminta" in block.data["permintaan"]:
                total_emissions += block.data["permintaan"]["ptbae_diminta"]
            elif "penawaran" in block.data and "ptbae_ditawarkan" in block.data["penawaran"]:
                total_emissions += block.data["penawaran"]["ptbae_ditawarkan"]
        return total_emissions

    def add_transaksi(self, transaksi):
        if isinstance(transaksi, Transaksi):
            transaksi_dict = transaksi.__dict__
            new_block = Block(datetime.now().timestamp(), {"transaksi": transaksi_dict}, self.blocks[-1].hash)
            new_block.hash = new_block.calculate_hash()
            self.blocks.append(new_block)
        else:
            raise ValueError("Data yang diberikan harus berupa objek Transaksi")
    
    def __repr__(self):
        return f"Blockchain(blocks=[\n" + "\n".join(
            [
                f"    Block(timestamp={block.timestamp}, data={block.data}, previous_hash={block.previous_hash})"
                for block in self.blocks
            ]
        ) + f"\n], total_emissions={self.calculate_total_emissions()})"

def main():
    # Contoh data permintaan
    permintaan = Permintaan(
        id=1,
        id_pelaku_usaha=1,
        id_periode=1,
        tanggal_permintaan="2023-07-20",
        tanggal_awal_berlaku="2023-07-20",
        tanggal_akhir_berlaku="2023-08-20",
        ptbae_diminta=100,
        satuan="ton CO2e",
        harga=1000000,
        mata_uang="IDR",
        jumlah_terbeli=0,
        satuan_terbeli="ton CO2e",
        sisa_permintaan=100,
        satuan_sisa_permintaan="ton CO2e",
        tanggal_terbeli="2023-07-20",
        created_by=1,
        created_at="2023-07-20T00:00:00Z",
        last_modified_by=1,
        last_modified_at="2023-07-20T00:00:00Z",
        is_deleted=False,
        status="permintaan_dibuat",
        available_permintaan=100,
        is_spe=False,
        is_direct_offset=False,
        user={
            "id_pelaku_usaha": 1,
            "nama": "PELAKU USAHA 1",
            "beli_dari_pelaku_usaha": None,
            "id_pelaku_usaha_penawaran": None,
        },
    )

    # contoh penawaran
    penawaran = Penawaran(
        id=1,
        id_pelaku_usaha=1,
        id_periode=1,
        tanggal_penawaran="2023-07-20",
        tanggal_awal_berlaku="2023-07-20",
        tanggal_akhir_berlaku="2023-08-20",
        ptbae_ditawarkan=100,
        satuan="ton CO2e",
        harga=1000000,
        mata_uang="IDR",
        jumlah_terjual=0,
        satuan_terjual="ton CO2e",
        sisa_penawaran=100,
        satuan_sisa_penawaran="ton CO2e",
        tanggal_terjual="2023-07-20",
        created_by=1,
        created_at="2023-07-20T00:00:00Z",
        last_modified_by=1,
        last_modified_at="2023-07-20T00:00:00Z",
        is_deleted=False,
        status="penawaran_dibuat",
        available_penawaran=100,
        is_spe=False,
    )

    #contoh transaksi
    # Buat objek transaksi
    transaksi = Transaksi(
        id=1,
        id_periode=1,
        kode_transaksi="jual",
        tanggal_transaksi="2023-07-20",
        id_pelaku_usaha=1,
        beli_dari_pelaku_usaha=2,
        jumlah_karbon_masuk=100,
        satuan_karbon_masuk="ton CO2e",
        harga_beli=1000000,
        nilai_beli_karbon=100000000,
        satuan_harga="IDR",
        jual_ke=3,
        jumlah_karbon_keluar=100,
        satuan_karbon_keluar="ton CO2e",
        harga_jual=1000000,
        satuan_harga_jual="IDR",
        nilai_jual_karbon=100000000,
        token="1234567890",
        saldo_emisi=-100,
        satuan_saldo="ton CO2e",
        saldo_nilai_ekonomi=-100000000,
        satuan_mata_uang="IDR",
        token_expired="2023-08-20",
        approval_status="approved",
        approved_by=1,
        approved_at="2023-07-20T00:00:00Z",
        created_by=1,
        created_at="2023-07-20T00:00:00Z",
        modified_by=1,
        is_deleted=False,
        file="",
        id_penawaran=1,
        id_permintaan=None,
        id_transaksi_origin=None,
        is_spe=False,
        is_direct_offset=True,
    )

    # Buat blockchain
    blockchain = Blockchain()

    # Tambah blok baru
    blockchain.add_block(permintaan)
    blockchain.add_block(penawaran)
    
    # Tambah blok baru menggunakan metode add_transaksi
    blockchain.add_transaksi(transaksi)

    # Cetak blockchain
    print(blockchain)


if __name__ == "__main__":
    main()
