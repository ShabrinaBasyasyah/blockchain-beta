from flask import Flask, jsonify, request, render_template
from blockchain import Blockchain
from datetime import datetime
from permintaan import Permintaan
from penawaran import Penawaran
from transaksi import Transaksi

app = Flask(__name__, template_folder='templates')
blockchain = Blockchain()

# Endpoint to get the entire blockchain
@app.route('/blockchain', methods=['GET'])
def get_blockchain():
    return jsonify(blockchain.blockchain_dict())

# Endpoint to add a new offer to the blockchain
@app.route('/penawaran', methods=['POST'])
def add_penawaran():
    try:
        penawaran_data = request.get_json()
        penawaran = Penawaran(**penawaran_data)
        blockchain.add_block(penawaran)
        return jsonify({"message": "Penawaran berhasil ditambahkan!"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# Endpoint to add a new request to the blockchain
@app.route('/permintaan', methods=['POST'])
def add_permintaan():
    try:
        permintaan_data = request.get_json()
        permintaan = Permintaan(**permintaan_data)
        blockchain.add_block(permintaan)
        return jsonify({"message": "Permintaan berhasil ditambahkan!"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# Endpoint to add a new transaction to the blockchain
@app.route('/transaksi/add', methods=['POST'])
def add_transaksi():
    try:
        transaksi_data = request.get_json()
        transaksi = Transaksi(**transaksi_data)
        blockchain.add_block(transaksi)
        return jsonify({"message": "Transaksi berhasil ditambahkan!"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# Endpoint to view the entire blockchain
@app.route('/view_blockchain_data', methods=['GET'])
def view_blockchain_data():
    return jsonify(blockchain.blockchain_dict())

@app.route('/add_transaksi_user_input', methods=['GET', 'POST'])
def add_transaksi_user_input():
    if request.method == 'POST':
        try:
            # User input for Transaksi
            transaksi = Transaksi.from_user_input()
            if transaksi is not None:
                blockchain.add_transaksi(transaksi)
                return jsonify({"message": "Transaksi berhasil ditambahkan!"}), 201
            else:
                return jsonify({"error": "Data transaksi tidak valid."}), 400
        except Exception as e:
            return jsonify({"error": str(e)}), 400
    else:
        # Render the form for GET requests
        return render_template('form_transaksi_user_input.html')

@app.route('/add_permintaan_user_input', methods=['GET', 'POST'])
def add_permintaan_user_input():
    if request.method == 'POST':
        try:
            # User input for Permintaan
            permintaan = Permintaan.from_user_input()
            if permintaan is not None:
                blockchain.add_permintaan(permintaan)
                return jsonify({"message": "Permintaan berhasil ditambahkan!"}), 201
            else:
                return jsonify({"error": "Data permintaan tidak valid."}), 400
        except Exception as e:
            return jsonify({"error": str(e)}), 400
    else:
        # Render the form for GET requests
        return render_template('form_permintaan_user_input.html')

@app.route('/add_penawaran_user_input', methods=['GET', 'POST'])
def add_penawaran_user_input():
    if request.method == 'POST':
        try:
            # User input for Penawaran
            penawaran = Penawaran.from_user_input()
            if penawaran is not None:
                blockchain.add_penawaran(penawaran)
                return jsonify({"message": "Penawaran berhasil ditambahkan!"}), 201
            else:
                return jsonify({"error": "Data penawaran tidak valid."}), 400
        except Exception as e:
            return jsonify({"error": str(e)}), 400
    else:
        # Render the form for GET requests
        return render_template('form_penawaran_user_input.html')

if __name__ == "__main__":
    app.run(debug=True)
